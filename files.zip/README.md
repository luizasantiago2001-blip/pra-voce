# 💛 uma coisa meio idiota (no bom sentido)

> Um jogo interativo romântico feito com HTML, CSS e JavaScript puro.  
> Leve, íntimo, divertido — e com um pedido especial no final.

---

## 🗂️ Estrutura do projeto

```
romantic-game/
├── index.html   ← estrutura e textos do jogo
├── style.css    ← visual, cores e animações
├── script.js    ← lógica, mini-games e interações
└── README.md    ← você está aqui
```

---

## ▶️ Como rodar localmente

1. **Baixe os arquivos** (ou clone o repositório):
   ```bash
   git clone https://github.com/SEU-USUARIO/SEU-REPO.git
   cd SEU-REPO
   ```

2. **Abra o `index.html`** no navegador:
   - Dê duplo clique no arquivo, **ou**
   - Use uma extensão como **Live Server** no VS Code para ter reload automático.

3. Pronto! O jogo abre direto no browser, sem instalar nada. ✦

---

## 🎵 Adicionando música de fundo (opcional)

1. Coloque um arquivo `music.mp3` na mesma pasta do projeto.
2. Abra o `index.html` e encontre essa linha (por volta da linha 18):
   ```html
   <!-- <source src="music.mp3" type="audio/mpeg" /> -->
   ```
3. Remova os comentários, deixando assim:
   ```html
   <source src="music.mp3" type="audio/mpeg" />
   ```
4. Ao clicar no botão 🎵 no canto da tela, a música vai tocar.

> **Sugestão de músicas suaves:** procure no YouTube por *"lofi romantic piano"* ou *"soft acoustic love songs"* e baixe em mp3 com um conversor online.

---

## ✏️ Personalizando os textos

Todos os textos do jogo estão no **`index.html`**, dentro das seções `<section class="screen" id="screen-N">`.

Para editar uma mensagem, basta abrir o arquivo e alterar o conteúdo das tags `<p>` ou `<h2>` de cada tela.

Exemplo (Tela 2):
```html
<h2 class="title italic">desde o primeiro momento…</h2>
<p class="body-text">
  Eu ainda acho meio doido pensar que...
  <!-- ↑ edite aqui ↑ -->
</p>
```

---

## 🚀 Publicando no GitHub Pages

### Passo 1 — Crie o repositório

1. Acesse [github.com/new](https://github.com/new)
2. Nomeie o repositório (ex: `pra-voce` ou deixe privado se preferir)
3. Clique em **Create repository**

### Passo 2 — Suba os arquivos

**Via interface web (mais fácil):**
1. Dentro do repositório, clique em **Add file → Upload files**
2. Arraste os 3 arquivos: `index.html`, `style.css`, `script.js`
3. Clique em **Commit changes**

**Via terminal:**
```bash
git init
git add .
git commit -m "💛 primeiro commit"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/SEU-REPO.git
git push -u origin main
```

### Passo 3 — Ative o GitHub Pages

1. Vá em **Settings** do repositório
2. No menu lateral, clique em **Pages**
3. Em *Source*, selecione **Deploy from a branch**
4. Escolha a branch **main** e a pasta **/ (root)**
5. Clique em **Save**

Aguarde 1-2 minutos e seu jogo estará disponível em:
```
https://SEU-USUARIO.github.io/SEU-REPO/
```

> 💡 **Dica:** Se quiser que o link seja mais discreto, renomeie o repositório para algo genérico antes de mandar pra ela — aí você manda o link direto sem spoiler.

---

## 💌 Sugestão de como mandar

Antes de enviar o link, manda algo tipo:

> *"eu fiz uma coisa meio idiota (no bom sentido) pra gente, depois você vê kkk"*

Isso tira o peso, deixa espontâneo e sem obrigação. Funciona.

---

## 🛠️ Detalhes técnicos

- **Zero dependências** — HTML, CSS e JS puros
- **Responsivo** — funciona bem em celular e desktop
- **Acessível** — navegação por teclado, respeita `prefers-reduced-motion`
- **Efeito sonoro** — gerado via Web Audio API (sem arquivos externos)
- **Fontes** — Cormorant Garamond + DM Sans (via Google Fonts)

---

*feito com muito carinho ✦*
